# vrtp

To run locally use the following command in the root directory:
`npm start`
