export const affirmations = [
  "Remember to drink your water",
  "Take a 15 min walk",
  "Light a candle",
  "Take a soothing bath"
]